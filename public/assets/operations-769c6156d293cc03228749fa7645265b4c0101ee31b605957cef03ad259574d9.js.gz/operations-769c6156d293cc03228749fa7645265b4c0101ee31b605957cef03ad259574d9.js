var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// app/javascript/operations.js
var require_operations = __commonJS({
  "app/javascript/operations.js"(exports) {
    (function() {
    }).call(exports);
  }
});
export default require_operations();
