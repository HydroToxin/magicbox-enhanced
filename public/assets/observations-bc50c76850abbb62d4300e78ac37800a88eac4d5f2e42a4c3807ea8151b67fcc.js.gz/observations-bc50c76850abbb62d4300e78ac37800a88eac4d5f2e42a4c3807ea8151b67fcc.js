var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// app/javascript/observations.js
var require_observations = __commonJS({
  "app/javascript/observations.js"(exports) {
    (function() {
    }).call(exports);
  }
});
export default require_observations();
