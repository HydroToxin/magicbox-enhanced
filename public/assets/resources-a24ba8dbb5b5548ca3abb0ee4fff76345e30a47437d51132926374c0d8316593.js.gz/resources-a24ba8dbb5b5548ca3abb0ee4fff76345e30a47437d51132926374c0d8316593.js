var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// app/javascript/resources.js
var require_resources = __commonJS({
  "app/javascript/resources.js"(exports) {
    (function() {
    }).call(exports);
  }
});
export default require_resources();
