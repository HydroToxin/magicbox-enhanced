var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// app/javascript/strains.js
var require_strains = __commonJS({
  "app/javascript/strains.js"(exports) {
    (function() {
    }).call(exports);
  }
});
export default require_strains();
