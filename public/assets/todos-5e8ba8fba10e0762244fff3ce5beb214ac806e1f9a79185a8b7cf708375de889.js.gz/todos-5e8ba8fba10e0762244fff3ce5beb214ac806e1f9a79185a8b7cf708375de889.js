var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// app/javascript/todos.js
var require_todos = __commonJS({
  "app/javascript/todos.js"(exports) {
    (function() {
    }).call(exports);
  }
});
export default require_todos();
